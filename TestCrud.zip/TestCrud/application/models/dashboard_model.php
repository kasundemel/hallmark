<?php
/**
 * Created by PhpStorm.
 * User: Kasun De Mel
 * Date: 1/16/2018
 * Time: 1:27 AM
 */
class dashboard_model extends CI_Model{

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function save($data){
        $this->db->insert('employees',$data);
        return $this->db->insert_id();
    }
}