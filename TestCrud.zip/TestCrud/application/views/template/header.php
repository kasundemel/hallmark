<?php
/**
 * Created by PhpStorm.
 * User: Kasun De Mel
 * Date: 1/15/2018
 * Time: 10:18 PM
 */
?>
<!DOCTYPE HTML>
<HTML>
<header>
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css');?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap-grid.css');?>">
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap-reboot.css');?>">
    <javascript src="<?php echo base_url('assets/bootstrap/js/bootstrap.bundle.js'); ?>"></javascript>
    <javascript src="<?php echo base_url('assets/bootstrap/js/bootstrap.js'); ?>"></javascript>
    <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js'); ?>"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
</header>
<body>
<br>
<div class="col-md-12">

