<div class="col-md-8 col-md-offset-2" style="margin-left:200px">
    <div class="box-header">
        <button class="btn btn-primary" onclick="add_new()">Add New Job</button>
    </div>
    <br>
    <div class="box-body">
        <table id="employees_table" class="table table-hover table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Age</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <div class="box-footer">

    </div>

    <!-- Modal -->
    <div class="modal" id="add_new_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #3991ff">
                    <h5 class="modal-title" style="color: #ffffff">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <form id="test_form">
                            <div class="col-md-12">
                                <div class="row">
                                    <label class="col-md-6">Name</label>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control" id="name" name="name">
                                        <p class="error" id="name_alert" style="color: red"></p>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <label class="col-md-6">Select Gender</label>
                                    <div class="col-md-6">
                                        <select class="form-control" id="gender" name="gender" style="height: 40px">
                                            <option>---select---</option>
                                            <option value="M">Male</option>
                                            <option value="F">FeMale</option>
                                        </select>
                                        <p class="error" id="gender_alert" style="color: red"></p>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <label class="col-md-6">Age</label>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control" id="age" name="age">
                                        <p class="error" id="age_alert" style="color: red"></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" onclick="save()">Save</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>


<script>

    var employees;
    $(document).ready(function(){

        employees=$('#employees_table').DataTable({

            "processing": true,
            "serverSide": true,
            "order": [],
            "searching": true,
            "ajax": {
                "data": {
                    "<?php echo $this->security->get_csrf_token_name(); ?>": "<?php echo $this->security->get_csrf_hash(); ?>"
                },
                "url": "<?php echo site_url('dashboard/get_ajax_employees'); ?>",
                "type": "POST"
            },
            "columnDefs":[
                {
                    "targets": [ -1 ],
                    "orderable":true
                }
            ]
        });

    });

    function reload_table(employees)
    {
        employees.ajax.reload(); //reload datatable ajax
    }

    function add_new(){
        $('#add_new_modal').modal('show');
    }

    function save(){
        var name=$('#name').val();
        var age=$('#age').val();
        var gender=$('#gender').val();

        if(name=="" || age=="" || gender==""){
            if(name==""){
                $('#name_alert').text('Please Enter Name');
            }
            else{
                $('#name_alert').text('');
            }
            if(age==""){
                $('#name_alert').text('Please Enter Age');
            }
            else{
                $('#name_alert').text('');
            }
            if(gender==""){
                $('#name_alert').text('Please Select Gender');
            }
            else{
                $('#name_alert').text('');
            }
        }
        else{

            $.ajax({
                url:"<?php echo site_url('dashboard/save');?>",
                type:"post",
                DataType:"JSON",
                data:$('#test_form').serialize()+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
                success:function(data){
                    console.log(data);
                    reload_table(employees);
                },
                error:function(){
                    console.log('error');
                }
            });
        }
    }

</script>