<?php
/**
 * Created by PhpStorm.
 * User: Kasun De Mel
 * Date: 1/15/2018
 * Time: 10:18 PM
 */

?>
<br>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="row" style="margin-left: 410px;">
            <button class="col-md-3 btn btn-success">First Page</button>
            <button class="col-md-3 btn btn-success">Second Page</button>
            <button class="col-md-3 btn btn-success">Third Page</button>
            <button class="col-md-3 btn btn-success">Fourth Page</button>
        </div>
    </div>
</div>
