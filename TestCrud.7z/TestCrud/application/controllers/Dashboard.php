<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->library('ion_auth');
        $this->load->model('dashboard_model');
        $this->load->library('datatables');

        if (!$this->ion_auth->logged_in())
        {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
    }

	public function index()
	{
        $this->load->view('template/header');
        $this->load->view('template/main_menu');
		$this->load->view('dashboard_index');
		$this->load->view('template/footer');
	}

    public function get_ajax_employees(){
        $this->load->library('datatables');
        $this->datatables->select("
            employees.id as emp_id,
            employees.id,
            name,
            gender,
            age,
        ",FALSE);

        $this->datatables->from("employees");
        $this->datatables->add_column("Actions","<a href='".site_url('dashboard/index/$1')."'>Edit</a>","emp_id");
        $this->datatables->unset_column("emp_id");

        echo $this->datatables->generate();
    }

    public function save(){

        $data=array(
            'name'=>$this->input->post('name'),
            'age'=>$this->input->post('age'),
            'gender'=>$this->input->post('gender'),
        );

        $this->dashboard_model->save($data);
        echo json_encode(array('status'=>TRUE));
    }
}
